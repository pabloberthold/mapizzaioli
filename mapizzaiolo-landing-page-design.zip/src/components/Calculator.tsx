import { useEffect, useRef, useState, type CSSProperties } from "react";
import { PRESETS, calcDough, fermentAdvice, fmtG } from "../lib/dough";
import { Reveal, useCountUp } from "../lib/motion";
import { IconCheck, IconCopy, IconFlame } from "./icons";

function Slider({
  label,
  value,
  min,
  max,
  step,
  unit,
  decimals = 0,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  decimals?: number;
  onChange: (v: number) => void;
}) {
  const fill = ((value - min) / (max - min)) * 100;
  return (
    <div className="mb-5">
      <div className="flex items-baseline justify-between mb-1">
        <label className="text-[13.5px] font-semibold text-cream-dim">{label}</label>
        <span className="font-calc text-[15px] font-semibold text-gold tabular-nums">
          {value.toFixed(decimals).replace(".", ",")}
          <span className="text-[11px] text-cream-dim font-normal ml-1">{unit}</span>
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{ "--fill": `${fill}%` } as CSSProperties}
        aria-label={label}
      />
    </div>
  );
}

function OutNumber({
  label,
  value,
  big = false,
  decimals = 0,
}: {
  label: string;
  value: number;
  big?: boolean;
  decimals?: number;
}) {
  const v = useCountUp(value, 280);
  return (
    <div className="border-b border-cream/10 pb-4">
      <p className="text-[12px] font-semibold uppercase tracking-[0.14em] text-cream-dim mb-1">
        {label}
      </p>
      <p
        className={`font-calc font-semibold tabular-nums leading-none ${
          big ? "text-4xl md:text-[2.9rem] text-cream" : "text-2xl md:text-3xl text-gold"
        }`}
      >
        {v.toFixed(decimals).replace(".", ",")}
        <span className="text-[13px] text-cream-dim font-normal ml-1.5">g</span>
      </p>
    </div>
  );
}

const RING_R = 48;
const RING_C = 2 * Math.PI * RING_R;

export default function Calculator() {
  const [presetId, setPresetId] = useState("napoli");
  const [balls, setBalls] = useState(4);
  const [ballWeight, setBallWeight] = useState(250);
  const [hydration, setHydration] = useState(65);
  const [salt, setSalt] = useState(3);
  const [yeast, setYeast] = useState(0.3);
  const [copied, setCopied] = useState(false);
  const timer = useRef<number | null>(null);

  const preset = PRESETS.find((p) => p.id === presetId) ?? PRESETS[0];
  const total = balls * ballWeight;
  const d = calcDough(total, hydration, salt, yeast);
  const advice = fermentAdvice(hydration, yeast, preset);

  const isCustom =
    hydration !== preset.hydration || salt !== preset.salt || yeast !== preset.yeast;

  useEffect(() => {
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, []);

  const applyPreset = (id: string) => {
    const p = PRESETS.find((x) => x.id === id);
    if (!p) return;
    setPresetId(id);
    setHydration(p.hydration);
    setSalt(p.salt);
    setYeast(p.yeast);
  };

  const copyFormula = async () => {
    const text = [
      `Ma'pizzaiolo · Pizza ${preset.name}${isCustom ? " (ajustada)" : ""}`,
      `${balls} bola${balls > 1 ? "s" : ""} de ${ballWeight} g — total ${fmtG(d.total)} g`,
      `Harina: ${fmtG(d.flour)} g`,
      `Agua: ${fmtG(d.water)} g`,
      `Sal: ${fmtG(d.saltG)} g`,
      `Levadura fresca: ${fmtG(d.yeastG)} g`,
      `Fermentación: ${advice.range}`,
    ].join("\n");
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
      } catch {
        /* silencioso */
      }
      document.body.removeChild(ta);
    }
    setCopied(true);
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setCopied(false), 2400);
  };

  // Anillo de proporciones
  const fr = {
    flour: d.flour / d.total,
    water: d.water / d.total,
    salt: d.saltG / d.total,
    yeast: Math.max(d.yeastG / d.total, 0.015),
  };
  const norm = fr.flour + fr.water + fr.salt + fr.yeast;
  const segs = [
    { key: "Harina", frac: fr.flour / norm, color: "#F2E7D2" },
    { key: "Agua", frac: fr.water / norm, color: "#7FB2D9" },
    { key: "Sal", frac: fr.salt / norm, color: "#F2B24C" },
    { key: "Levadura", frac: fr.yeast / norm, color: "#8FB573" },
  ];
  let acc = 0;
  const ringSegs = segs.map((s) => {
    const start = acc;
    acc += s.frac;
    return { ...s, start };
  });

  const STEPS = [
    ["Mezcla", "harina + agua, 10 min"],
    ["Autólisis", "reposo 30 min"],
    ["Plegados", "cada 30 min, +sal y levadura"],
    ["Fermentación", advice.range.split(" o ")[0].toLowerCase()],
  ];

  return (
    <section id="calculadora" className="relative py-24 md:py-32 overflow-hidden">
      <div
        className="absolute inset-x-0 top-0 h-[600px] bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(255,107,44,0.14),transparent)]"
        aria-hidden="true"
      />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <Reveal>
            <p className="font-calc text-[11px] uppercase tracking-[0.3em] text-ember mb-4">
              02 · La calculadora
            </p>
            <h2 className="font-display text-4xl md:text-5xl font-semibold tracking-tight leading-[1.05]">
              Tu fórmula, lista en <em className="italic text-gold font-medium">20 segundos</em>.
            </h2>
            <p className="mt-5 text-cream-dim leading-relaxed">
              Elige el estilo, dime cuántas pizzas horneas y qué bola pesa.
              El resto — agua, sal, levadura, fermentación — lo hace la fórmula.
            </p>
          </Reveal>
        </div>

        <Reveal scale className="rounded-3xl border border-cream/10 bg-gradient-to-b from-[#1B150E] to-[#120E0A] shadow-[0_50px_120px_-40px_rgba(0,0,0,0.9)] overflow-hidden">
          <div className="grid lg:grid-cols-5">
            {/* -------- ENTRADAS -------- */}
            <div className="lg:col-span-2 p-7 md:p-9 lg:border-r border-b lg:border-b-0 border-cream/10">
              <p className="font-calc text-[11px] uppercase tracking-[0.24em] text-cream-dim mb-4">
                01 · Estilo
              </p>
              <div className="grid grid-cols-2 gap-2.5 mb-8" role="group" aria-label="Estilo de pizza">
                {PRESETS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => applyPreset(p.id)}
                    aria-pressed={presetId === p.id}
                    className={`text-left rounded-xl border px-3.5 py-3 transition-all duration-300 cursor-pointer ${
                      presetId === p.id
                        ? "border-ember bg-ember/10 shadow-[0_0_24px_-6px_rgba(255,107,44,0.5)]"
                        : "border-cream/12 hover:border-cream/30 hover:bg-cream/[0.03]"
                    }`}
                  >
                    <span
                      className={`block text-[13.5px] font-bold ${
                        presetId === p.id ? "text-gold" : "text-cream"
                      }`}
                    >
                      {p.name}
                    </span>
                    <span className="block text-[11px] text-cream-dim mt-0.5 truncate">{p.tag}</span>
                  </button>
                ))}
              </div>

              <p className="font-calc text-[11px] uppercase tracking-[0.24em] text-cream-dim mb-4">
                02 · Tamaño
              </p>
              <div className="flex items-center justify-between rounded-xl border border-cream/12 bg-cream/[0.03] px-4 py-3 mb-5">
                <span className="text-[13.5px] font-semibold text-cream-dim">Bolas de masa</span>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setBalls((b) => Math.max(1, b - 1))}
                    aria-label="Quitar una bola"
                    className="w-8 h-8 rounded-full border border-cream/20 grid place-items-center text-cream text-lg leading-none hover:border-ember hover:text-gold active:scale-90 transition-all"
                  >
                    −
                  </button>
                  <span className="font-calc text-xl font-semibold text-cream w-8 text-center tabular-nums">
                    {balls}
                  </span>
                  <button
                    onClick={() => setBalls((b) => Math.min(24, b + 1))}
                    aria-label="Añadir una bola"
                    className="w-8 h-8 rounded-full border border-cream/20 grid place-items-center text-cream text-lg leading-none hover:border-ember hover:text-gold active:scale-90 transition-all"
                  >
                    +
                  </button>
                </div>
              </div>
              <Slider
                label="Peso por bola"
                value={ballWeight}
                min={180}
                max={400}
                step={5}
                unit="g"
                onChange={setBallWeight}
              />

              <p className="font-calc text-[11px] uppercase tracking-[0.24em] text-cream-dim mb-4 flex items-center gap-2">
                03 · Fórmula
                {isCustom && (
                  <span className="font-body text-[10px] normal-case tracking-normal bg-gold/15 text-gold rounded-full px-2 py-0.5 font-bold">
                    ajustado a tu gusto
                  </span>
                )}
              </p>
              <Slider
                label="Hidratación"
                value={hydration}
                min={50}
                max={85}
                step={0.5}
                decimals={1}
                unit="%"
                onChange={setHydration}
              />
              <Slider
                label="Sal"
                value={salt}
                min={2}
                max={4}
                step={0.1}
                decimals={1}
                unit="%"
                onChange={setSalt}
              />
              <Slider
                label="Levadura fresca"
                value={yeast}
                min={0}
                max={2}
                step={0.05}
                decimals={2}
                unit="%"
                onChange={setYeast}
              />

              <div className="mt-5 font-calc text-[11.5px] text-cream-dim/80 bg-cream/[0.04] border border-cream/10 rounded-lg px-4 py-3">
                <span className="text-cream/60">Fórmula · </span>
                Harina 100 · Agua {hydration.toFixed(1).replace(".", ",")} · Sal{" "}
                {salt.toFixed(1).replace(".", ",")} · Levadura {yeast.toFixed(2).replace(".", ",")}
              </div>
            </div>

            {/* -------- RESULTADOS -------- */}
            <div className="lg:col-span-3 p-7 md:p-9 bg-[radial-gradient(ellipse_at_top_right,rgba(255,107,44,0.08),transparent_55%)]">
              <div className="flex items-center justify-between mb-7">
                <p className="font-calc text-[11px] uppercase tracking-[0.24em] text-cream-dim">
                  04 · Tu receta
                </p>
                <span className="inline-flex items-center gap-2 font-calc text-[10px] tracking-[0.18em] text-basil">
                  <span className="w-1.5 h-1.5 rounded-full bg-basil pulse-dot" aria-hidden="true" />
                  CALCULANDO EN VIVO
                </span>
              </div>

              <div className="grid grid-cols-2 gap-x-8 gap-y-5">
                <OutNumber label="Harina 00 / W" value={d.flour} big />
                <OutNumber label="Agua" value={d.water} big />
                <OutNumber label="Sal fina" value={d.saltG} decimals={1} />
                <OutNumber label="Levadura fresca" value={d.yeastG} decimals={1} />
              </div>

              <div className="mt-6 flex flex-wrap items-center justify-between gap-3 glass rounded-xl px-5 py-3.5">
                <p className="text-[13px] text-cream-dim">
                  Total masa{" "}
                  <span className="font-calc font-semibold text-cream text-[15px]">
                    {fmtG(d.total)} g
                  </span>
                </p>
                <p className="text-[13px] text-cream-dim">
                  <span className="font-calc font-semibold text-gold">{balls}</span> bolas de{" "}
                  <span className="font-calc font-semibold text-gold">{ballWeight} g</span>
                </p>
              </div>

              <div className="mt-7 flex flex-col md:flex-row gap-7">
                {/* Anillo de proporciones */}
                <div className="flex items-center gap-5 shrink-0">
                  <svg viewBox="0 0 120 120" className="w-[132px] h-[132px]" role="img" aria-label="Proporción de ingredientes">
                    <g transform="rotate(-90 60 60)">
                      <circle cx="60" cy="60" r={RING_R} fill="none" stroke="rgba(244,237,225,0.07)" strokeWidth="13" />
                      {ringSegs.map((s) => (
                        <circle
                          key={s.key}
                          cx="60"
                          cy="60"
                          r={RING_R}
                          fill="none"
                          stroke={s.color}
                          strokeWidth="13"
                          strokeDasharray={`${s.frac * RING_C} ${RING_C}`}
                          strokeDashoffset={-s.start * RING_C}
                          className="transition-all duration-500 ease-out"
                        />
                      ))}
                    </g>
                    <text x="60" y="57" textAnchor="middle" fill="#F4EDE1" fontSize="17" fontWeight="600" fontFamily="IBM Plex Mono, monospace">
                      {hydration.toFixed(0)}%
                    </text>
                    <text x="60" y="74" textAnchor="middle" fill="#A89C8B" fontSize="8" letterSpacing="2" fontFamily="IBM Plex Mono, monospace">
                      HIDRAT.
                    </text>
                  </svg>
                  <ul className="space-y-2">
                    {segs.map((s, i) => (
                      <li key={s.key} className="flex items-center gap-2 text-[12px] text-cream-dim">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ background: s.color }} aria-hidden="true" />
                        {s.key}
                        <span className="font-calc text-cream ml-auto pl-3 tabular-nums">
                          {fmtG([d.flour, d.water, d.saltG, d.yeastG][i])} g
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Fermentación */}
                <div
                  key={advice.range + preset.id}
                  className="fade-swap flex-1 glass rounded-xl p-5 border-l-2 border-l-ember"
                >
                  <p className="flex items-center gap-2 font-calc text-[10.5px] uppercase tracking-[0.2em] text-ember mb-2">
                    <IconFlame className="w-4 h-4" /> Fermentación sugerida
                  </p>
                  <p className="font-display text-xl font-semibold text-cream">{advice.range}</p>
                  <p className="mt-2 text-[13px] leading-relaxed text-cream-dim">{advice.note}</p>
                </div>
              </div>

              {/* Pasos */}
              <ol className="mt-7 grid grid-cols-2 md:grid-cols-4 gap-2.5">
                {STEPS.map(([t, sub], i) => (
                  <li key={t} className="rounded-lg border border-cream/10 bg-cream/[0.03] px-3.5 py-3">
                    <p className="font-calc text-[10px] text-ember mb-1">PASO {i + 1}</p>
                    <p className="text-[12.5px] font-bold text-cream leading-tight">{t}</p>
                    <p className="text-[11px] text-cream-dim mt-0.5 leading-snug">{sub}</p>
                  </li>
                ))}
              </ol>

              <div className="mt-8 flex flex-col sm:flex-row sm:items-center gap-4">
                <button onClick={copyFormula} className={`btn-primary flex-1 ${copied ? "!bg-none !bg-basil/90" : ""}`}>
                  {copied ? (
                    <>
                      <IconCheck className="w-5 h-5" /> ¡Fórmula copiada!
                    </>
                  ) : (
                    <>
                      <IconCopy className="w-5 h-5" /> Copiar mi fórmula
                    </>
                  )}
                </button>
                <p className="text-[12.5px] text-cream-dim sm:max-w-[190px]">
                  Gratis y sin cuenta. Tu fórmula, en la libreta en un toque.
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
