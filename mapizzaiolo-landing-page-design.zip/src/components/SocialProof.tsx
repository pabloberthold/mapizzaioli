import { Reveal } from "../lib/motion";
import { IconSlice } from "./icons";

const OUTLETS = [
  "Forno & Fiamma",
  "La Masa Journal",
  "Cocina de Barrio",
  "Il Vero Forno",
  "BakeLab Estudio",
  "Ocho Fuegos",
  "Pizza Society",
  "La Escuela del Pan",
];

function Row({ hidden = false }: { hidden?: boolean }) {
  return (
    <div className="flex items-center gap-16 shrink-0" aria-hidden={hidden || undefined}>
      {OUTLETS.map((o) => (
        <span key={o} className="flex items-center gap-16">
          <span className="font-display text-xl md:text-2xl font-medium text-cream/40 whitespace-nowrap hover:text-cream/80 transition-colors duration-300">
            {o}
          </span>
          <IconSlice className="w-4 h-4 text-ember/50 shrink-0" />
        </span>
      ))}
    </div>
  );
}

export default function SocialProof() {
  return (
    <section className="relative py-12 border-y border-cream/[0.07] bg-ink-2/60">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal>
          <p className="text-center font-calc text-[11px] uppercase tracking-[0.32em] text-cream-dim/80">
            Visto en · recomendado por quien hornea en serio
          </p>
        </Reveal>
      </div>

      <Reveal delay={140} className="marquee mt-8">
        <div className="marquee-track">
          <Row />
          <Row hidden />
        </div>
      </Reveal>

      <div className="mx-auto max-w-7xl px-5 sm:px-8 mt-9">
        <Reveal delay={220} className="flex flex-col sm:flex-row items-center justify-center gap-3 text-[13.5px] text-cream-dim">
          <span className="inline-flex items-center gap-2.5 glass rounded-full px-4 py-2">
            <span className="w-2 h-2 rounded-full bg-basil pulse-dot" aria-hidden="true" />
            <strong className="text-cream font-bold">12.438 cocineros</strong> calcularon esta semana
          </span>
          <span>
            96% repite su fórmula la semana siguiente
          </span>
        </Reveal>
      </div>
    </section>
  );
}
