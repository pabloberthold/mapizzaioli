import type { CSSProperties } from "react";
import { Counter, Reveal, useCountUp } from "../lib/motion";
import { IconArrow, IconStar, PizzaArt } from "./icons";

const FLOUR = [
  { left: "8%", top: "78%", size: 5, t: "9s", d: "0s" },
  { left: "16%", top: "60%", size: 3, t: "11s", d: "1.4s" },
  { left: "26%", top: "84%", size: 4, t: "10s", d: "3s" },
  { left: "38%", top: "70%", size: 3, t: "12s", d: "0.8s" },
  { left: "55%", top: "86%", size: 5, t: "9.5s", d: "2.2s" },
  { left: "68%", top: "64%", size: 3, t: "11.5s", d: "4s" },
  { left: "80%", top: "80%", size: 4, t: "10.5s", d: "1s" },
  { left: "90%", top: "58%", size: 3, t: "12.5s", d: "2.8s" },
  { left: "12%", top: "38%", size: 3, t: "13s", d: "5s" },
  { left: "86%", top: "34%", size: 4, t: "12s", d: "3.6s" },
];

const HERO_FORMULA = { flour: 248, water: 161, salt: 7.4, yeast: 0.7 };

function HeroStat({
  value,
  decimals = 0,
  prefix = "",
  suffix = "",
  label,
  delay,
}: {
  value: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  label: string;
  delay: number;
}) {
  return (
    <Reveal delay={delay} className="text-center md:text-left">
      <p className="font-calc text-3xl md:text-[2.1rem] font-semibold text-cream tracking-tight">
        <Counter
          to={value}
          decimals={decimals}
          prefix={prefix}
          suffix={suffix}
          className="bg-gradient-to-b from-cream to-gold/80 bg-clip-text text-transparent"
        />
      </p>
      <p className="mt-1.5 text-[13px] font-medium text-cream-dim leading-snug">{label}</p>
    </Reveal>
  );
}

function MiniRow({ label, grams, decimals = 0, delay }: { label: string; grams: number; decimals?: number; delay: number }) {
  const v = useCountUp(grams, 1500 + delay, true);
  return (
    <div className="flex items-baseline justify-between gap-3 py-2 border-b border-cream/10 last:border-0">
      <span className="text-[13px] font-medium text-cream-dim">{label}</span>
      <span className="font-calc text-lg font-semibold text-gold tabular-nums">
        {v.toFixed(decimals).replace(".", ",")} <span className="text-[11px] text-cream-dim font-normal">g</span>
      </span>
    </div>
  );
}

export default function Hero() {
  return (
    <section id="inicio" className="relative overflow-hidden pt-32 md:pt-40 pb-14">
      {/* Orbes ambientales */}
      <div className="orb w-[520px] h-[520px] bg-ember/25 -top-56 -right-40" aria-hidden="true" />
      <div
        className="orb w-[420px] h-[420px] bg-gold/15 top-1/2 -left-52"
        style={{ animationDelay: "-8s" }}
        aria-hidden="true"
      />
      {/* Partículas de harina */}
      <div className="absolute inset-0" aria-hidden="true">
        {FLOUR.map((f, i) => (
          <span
            key={i}
            className="flour-dot"
            style={
              {
                left: f.left,
                top: f.top,
                width: f.size,
                height: f.size,
                "--t": f.t,
                "--d": f.d,
              } as CSSProperties
            }
          />
        ))}
      </div>

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid lg:grid-cols-12 gap-14 lg:gap-8 items-center">
          {/* Columna de texto */}
          <div className="lg:col-span-6 xl:col-span-6">
            <Reveal>
              <span className="inline-flex items-center gap-2.5 glass rounded-full pl-3 pr-4 py-1.5 text-[12px] font-calc uppercase tracking-[0.18em] text-cream-dim">
                <span className="w-2 h-2 rounded-full bg-ember pulse-dot" aria-hidden="true" />
                Calculadora de masa · fórmulas en vivo
              </span>
            </Reveal>

            <h1 className="mt-7 font-display font-semibold text-[2.9rem] leading-[1.04] sm:text-6xl xl:text-[4.6rem] tracking-tight">
              <span className="line-mask">
                <span style={{ "--d": "120ms" } as CSSProperties}>Masa perfecta,</span>
              </span>
              <span className="line-mask">
                <span style={{ "--d": "280ms" } as CSSProperties}>
                  al <em className="italic font-medium text-transparent bg-clip-text bg-gradient-to-r from-ember via-gold to-ember">gramo exacto</em>.
                </span>
              </span>
            </h1>

            <Reveal delay={480}>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-cream-dim">
                Ma&rsquo;pizzaiolo convierte recetas a ciegas en método de obrador:
                <span className="text-cream font-semibold"> harina, agua, sal y levadura</span>,
                calculadas por porcentajes de panadero para tu horno, tu harina y tu tiempo.
              </p>
            </Reveal>

            <Reveal delay={620} className="mt-9 flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <a href="#calculadora" className="btn-primary text-base">
                Calcular mi masa <IconArrow className="w-5 h-5" />
              </a>
              <a href="#metodo" className="btn-ghost text-base">
                Ver el método
              </a>
            </Reveal>

            <Reveal delay={760} className="mt-10 flex items-center gap-4">
              <div className="flex -space-x-2.5" aria-hidden="true">
                {[
                  ["LM", "from-ember to-gold"],
                  ["AT", "from-gold to-basil"],
                  ["RS", "from-ember-deep to-ember"],
                  ["CV", "from-basil to-water"],
                ].map(([ini, grad]) => (
                  <span
                    key={ini}
                    className={`w-9 h-9 rounded-full bg-gradient-to-br ${grad} border-2 border-ink grid place-items-center text-[10px] font-bold text-ink`}
                  >
                    {ini}
                  </span>
                ))}
              </div>
              <div>
                <div className="flex items-center gap-1 text-gold" aria-label="4,9 de 5 estrellas">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <IconStar key={i} className="w-3.5 h-3.5" />
                  ))}
                  <span className="ml-1.5 font-calc text-[12px] text-cream">4,9/5</span>
                </div>
                <p className="text-[12.5px] text-cream-dim mt-0.5">
                  12.438 reseñas de cocineros que ya no adivinan
                </p>
              </div>
            </Reveal>
          </div>

          {/* Columna visual */}
          <div className="lg:col-span-6 relative">
            <div className="absolute inset-0 grid place-items-center" aria-hidden="true">
              <div className="w-[440px] h-[440px] md:w-[560px] md:h-[560px] rounded-full bg-[radial-gradient(circle,rgba(255,107,44,0.22),transparent_65%)]" />
            </div>

            <Reveal scale delay={200} className="relative mx-auto w-[300px] sm:w-[380px] md:w-[440px] mt-2 lg:mt-0 mb-8 md:mb-2">
              <div className="breathe relative">
                <div className="spin-slower w-full aspect-square drop-shadow-[0_30px_60px_rgba(0,0,0,0.55)]">
                  <PizzaArt />
                </div>
              </div>

              {/* Chips flotantes */}
              <div className="floaty glass rounded-xl px-3.5 py-2 absolute -left-4 top-[12%] hidden sm:block" style={{ "--d": "0ms" } as CSSProperties}>
                <p className="font-calc text-[11px] uppercase tracking-widest text-cream-dim">Diámetro</p>
                <p className="font-calc text-sm font-semibold text-cream">Ø 30 cm</p>
              </div>
              <div className="floaty glass rounded-xl px-3.5 py-2 absolute -right-6 top-[30%] hidden sm:block" style={{ "--d": "1400ms" } as CSSProperties}>
                <p className="font-calc text-[11px] uppercase tracking-widest text-cream-dim">Hidratación</p>
                <p className="font-calc text-sm font-semibold text-gold">65%</p>
              </div>
              <div className="floaty glass rounded-xl px-3.5 py-2 absolute right-2 top-[68%] hidden md:block" style={{ "--d": "2600ms" } as CSSProperties}>
                <p className="font-calc text-[11px] uppercase tracking-widest text-cream-dim">Bolas</p>
                <p className="font-calc text-sm font-semibold text-cream">250 g c/u</p>
              </div>
            </Reveal>

            {/* Tarjeta de fórmula */}
            <Reveal delay={520} className="relative z-10 mx-auto md:absolute md:-bottom-4 md:left-1/2 md:-translate-x-1/2 w-full md:w-[360px]">
              <div className="glass rounded-2xl p-5 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.7)] hover:border-gold/30 transition-colors duration-500">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-calc text-[11px] uppercase tracking-[0.22em] text-cream-dim">
                    Tu fórmula · Napolitana
                  </p>
                  <span className="inline-flex items-center gap-1.5 font-calc text-[10px] text-basil">
                    <span className="w-1.5 h-1.5 rounded-full bg-basil pulse-dot" aria-hidden="true" /> EN VIVO
                  </span>
                </div>
                <MiniRow label="Harina 00" grams={HERO_FORMULA.flour} delay={0} />
                <MiniRow label="Agua" grams={HERO_FORMULA.water} delay={200} />
                <MiniRow label="Sal fina" grams={HERO_FORMULA.salt} decimals={1} delay={400} />
                <MiniRow label="Levadura fresca" grams={HERO_FORMULA.yeast} decimals={1} delay={600} />
                <div className="flex items-center justify-between mt-3">
                  <p className="text-[12px] text-cream-dim">4 bolas · 24 h en frío</p>
                  <a href="#calculadora" className="inline-flex items-center gap-1.5 text-[13px] font-bold text-gold hover:text-ember transition-colors">
                    Abrir calculadora <IconArrow className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </Reveal>
          </div>
        </div>

        {/* Banda de estadísticas */}
        <div className="mt-16 md:mt-24 pt-10 border-t border-cream/10 grid grid-cols-2 md:grid-cols-4 gap-8">
          <HeroStat value={250} suffix="k+" label="fórmulas calculadas en la plataforma" delay={0} />
          <HeroStat value={1} prefix="±" suffix=" g" label="precisión de báscula, cero tazas" delay={120} />
          <HeroStat value={4.9} decimals={1} suffix="/5" label="valoración media verificada" delay={240} />
          <HeroStat value={120} suffix="+" label="recetas de obrador en la biblioteca" delay={360} />
        </div>
      </div>
    </section>
  );
}
