import { Reveal } from "../lib/motion";
import { IconArrow, PizzaArt } from "./icons";

export default function CTA() {
  return (
    <section id="cta" className="relative overflow-hidden">
      <div
        className="absolute inset-0 bg-[linear-gradient(135deg,#ff8a45_0%,#ff6b2c_40%,#e8451b_75%,#c73a12_100%)]"
        aria-hidden="true"
      />
      {/* anillos decorativos */}
      <div
        className="absolute -top-40 -left-40 w-[420px] h-[420px] rounded-full border-[30px] border-[#1c0e04]/10"
        aria-hidden="true"
      />
      <div
        className="absolute -bottom-56 -right-24 w-[560px] h-[560px] rounded-full border-[40px] border-[#1c0e04]/10"
        aria-hidden="true"
      />
      <div className="absolute -right-20 -bottom-32 w-[340px] h-[340px] opacity-90 hidden md:block" aria-hidden="true">
        <div className="spin-slower w-full h-full">
          <PizzaArt />
        </div>
      </div>

      <div className="relative mx-auto max-w-4xl px-5 sm:px-8 py-24 md:py-32 text-center">
        <Reveal>
          <p className="font-calc text-[11px] uppercase tracking-[0.32em] text-[#3a1d0c]/70 mb-5">
            El horno ya está caliente
          </p>
          <h2 className="font-display text-[2.7rem] md:text-6xl font-semibold tracking-tight leading-[1.03] text-[#1c0e04]">
            Tu mejor pizza
            <br />
            empieza <em className="italic font-medium text-[#5a2408]">pesando</em>.
          </h2>
          <p className="mt-6 max-w-xl mx-auto text-[17px] leading-relaxed text-[#3a1d0c]/80">
            Calcula tu primera fórmula en 20 segundos. Gratis, para siempre,
            y con el resto de tu cena todavía tibia.
          </p>
        </Reveal>
        <Reveal delay={180} className="mt-10">
          <a
            href="#calculadora"
            className="btn-dark !text-[15px] !px-9 !py-4 group"
          >
            Calcular mi masa gratis
            <IconArrow className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
          </a>
          <p className="mt-5 font-calc text-[11.5px] tracking-wide text-[#3a1d0c]/60">
            SIN TARJETA · SIN REGISTRO · SIN TAZAS MEDidoras
          </p>
        </Reveal>
      </div>
    </section>
  );
}
