import { useState } from "react";
import { Reveal } from "../lib/motion";
import { IconPlus } from "./icons";

const ITEMS = [
  {
    q: "¿De verdad necesito una báscula?",
    a: "Sí, y no tiene que ser cara: cualquier báscula de cocina a 1 g basta. Las tazas varían hasta un 25% entre una receta y otra, y la masa es química: la química se mide, no se estima. Si ya pesas café, no te falta nada más.",
  },
  {
    q: "¿Funciona con cualquier harina?",
    a: "Con cualquier harina. La regla de oro: a mayor proteína, más agua aguanta. Usa el preset como punto de partida y súbele 3–5 puntos de hidratación si tu harina tiene más de 13% de proteína. En Maestro puedes crear perfiles exactos por marca de harina.",
  },
  {
    q: "¿Puedo usar levadura seca en vez de fresca?",
    a: "Sí. Como regla rápida: multiplica el valor de la fresca por 0,35 (a 0,3% fresca le corresponde ≈0,10% seca) y alarga el frío unas horas. En el plan Artigiano la calculadora hace la conversión por ti dentro de la fórmula.",
  },
  {
    q: "¿Hidratación alta o baja: cuál elijo?",
    a: "No hay una «correcta»: depende del estilo y de tu horno. Empieza en 60–65% y sube 3 puntos por semana. Cada preset trae su rango y el porqué detrás, para que subas de hidratación con plan y no con miedo.",
  },
  {
    q: "¿Cuánto debo fermentar exactamente?",
    a: "El planificador lo calcula con tu hidratación y tu levadura, entre 4 h en ambiente y 72 h en frío. La regla de la casa: más tiempo equivale a más sabor, no a más esfuerzo. La masa trabaja mientras duermes.",
  },
  {
    q: "¿Guarda mis fórmulas favoritas?",
    a: "En Artigiano y Maestro cada fórmula se guarda en tu historial con fecha, notas y resultado. La pizza que triunfó el 14 de marzo vuelve a reproducirse al gramo con un clic, estés donde estés.",
  },
  {
    q: "¿Sirve para hornos domésticos?",
    a: "Es más bien lo contrario: los presets se ajustan a horno de casa — piedra o plancha — con tiempos de precalentado de 45 min y carga de calor máxima. Todo lo que una receta de pizzería no te dice, está aquí.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number>(0);

  return (
    <section id="faq" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-3xl px-5 sm:px-8">
        <div className="text-center mb-14">
          <Reveal>
            <p className="font-calc text-[11px] uppercase tracking-[0.3em] text-ember mb-4">
              06 · Preguntas
            </p>
            <h2 className="font-display text-4xl md:text-5xl font-semibold tracking-tight leading-[1.05]">
              Antes de que <em className="italic text-gold font-medium">hornees</em>.
            </h2>
          </Reveal>
        </div>

        <div className="border-t border-cream/10">
          {ITEMS.map((item, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={item.q} delay={i * 60} className="border-b border-cream/10">
                <h3>
                  <button
                    onClick={() => setOpen(isOpen ? -1 : i)}
                    aria-expanded={isOpen}
                    aria-controls={`faq-panel-${i}`}
                    className="w-full flex items-center justify-between gap-6 py-5.5 text-left group cursor-pointer"
                  >
                    <span
                      className={`text-[16px] md:text-[17px] font-bold transition-colors duration-300 ${
                        isOpen ? "text-gold" : "text-cream group-hover:text-gold"
                      }`}
                    >
                      {item.q}
                    </span>
                    <span
                      className={`shrink-0 w-9 h-9 rounded-full border grid place-items-center transition-all duration-500 ${
                        isOpen
                          ? "rotate-45 border-ember bg-ember/15 text-gold"
                          : "border-cream/20 text-cream-dim group-hover:border-cream/40"
                      }`}
                      aria-hidden="true"
                    >
                      <IconPlus className="w-4.5 h-4.5" />
                    </span>
                  </button>
                </h3>
                <div id={`faq-panel-${i}`} className={`acc-panel ${isOpen ? "open" : ""}`}>
                  <div>
                    <p className="pb-6 pr-2 md:pr-14 text-[14.5px] leading-relaxed text-cream-dim">
                      {item.a}
                    </p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
