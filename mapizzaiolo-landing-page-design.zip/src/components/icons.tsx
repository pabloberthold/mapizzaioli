interface IconProps {
  className?: string;
}

const base = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.7,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

export function LogoMark({ className = "w-8 h-8" }: IconProps) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <circle cx="16" cy="16" r="13" fill="#F4EDE1" />
      <path d="M16 16 L16 3 A13 13 0 0 1 27.3 10.5 Z" fill="#FF6B2C" />
      <path d="M16 16 L25.4 20.6 A13 13 0 0 1 16 29 Z" fill="#E8501A" opacity="0.85" />
      <circle cx="16" cy="16" r="2.4" fill="#0C0A07" />
    </svg>
  );
}

export function IconDial({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M20.5 12a8.5 8.5 0 1 1-8.5-8.5" />
      <path d="M12 2.5V6M12 18v3.5M2.5 12H6M18 12h3.5" opacity="0.5" />
      <path d="M8.5 15.5l7-7" />
      <circle cx="9" cy="9" r="1.6" />
      <circle cx="15" cy="15" r="1.6" />
    </svg>
  );
}

export function IconSlice({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M12 21.5 3.5 5.5C6.6 3.6 9.2 2.7 12 2.7s5.4.9 8.5 2.8L12 21.5Z" />
      <path d="M4.6 7.3c2.8-1.7 5-2.4 7.4-2.4s4.6.7 7.4 2.4" opacity="0.5" />
      <circle cx="10" cy="9.5" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="14" cy="13" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="11.2" cy="16.5" r="0.9" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function IconScale({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M12 4v16M8 20h8" />
      <path d="M5 7h14" />
      <path d="M5 7 2.8 12a2.6 2.6 0 0 0 4.4 0L5 7Z" />
      <path d="M19 7l-2.2 5a2.6 2.6 0 0 0 4.4 0L19 7Z" />
      <path d="M12 4a1.6 1.6 0 1 0 0-.01" />
    </svg>
  );
}

export function IconSnow({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M12 2.5v19M4 7l16 10M4 17 20 7" />
      <path d="M12 2.5 9.8 4.7M12 2.5l2.2 2.2M12 21.5l-2.2-2.2M12 21.5l2.2-2.2" opacity="0.6" />
      <circle cx="12" cy="12" r="2.4" />
    </svg>
  );
}

export function IconStack({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <circle cx="12" cy="6.5" r="3.6" />
      <circle cx="6.5" cy="15.5" r="3.6" />
      <circle cx="17.5" cy="15.5" r="3.6" />
      <path d="M9.5 18.5a3.6 3.6 0 0 0 5 0" opacity="0.5" />
    </svg>
  );
}

export function IconCopy({ className = "w-5 h-5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <rect x="8.5" y="8.5" width="12" height="13" rx="2.5" />
      <path d="M15.5 8.5V6a2.5 2.5 0 0 0-2.5-2.5H6A2.5 2.5 0 0 0 3.5 6v7A2.5 2.5 0 0 0 6 15.5h2.5" />
      <path d="M12 13h5M12 16.5h3.5" opacity="0.6" />
    </svg>
  );
}

export function IconCheck({ className = "w-5 h-5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="m4.5 12.5 5 5 10-11" />
    </svg>
  );
}

export function IconStar({ className = "w-4 h-4" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path
        d="M12 2.8l2.8 5.9 6.4.8-4.7 4.4 1.2 6.3L12 17.1l-5.7 3.1 1.2-6.3L2.8 9.5l6.4-.8L12 2.8Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function IconQuote({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path
        d="M10 6.5c-3.2 1-5 3.3-5 6.7V18h6v-6H7.8c.2-2 1.2-3.3 3.2-4.2V6.5h-1Zm9 0c-3.2 1-5 3.3-5 6.7V18h6v-6h-3.2c.2-2 1.2-3.3 3.2-4.2V6.5h-1Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function IconPlus({ className = "w-5 h-5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}

export function IconArrow({ className = "w-5 h-5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M4.5 12h15M13.5 6l6 6-6 6" />
    </svg>
  );
}

export function IconMenu({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M4 7h16M4 12h16M4 17h10" />
    </svg>
  );
}

export function IconX({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M6 6l12 12M18 6 6 18" />
    </svg>
  );
}

export function IconFlame({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M12 3c3 3.8 6.5 6.1 6.5 10.2a6.5 6.5 0 0 1-13 0c0-2.1.9-3.9 2.4-5.6.4 1 1 1.9 1.9 2.4C10 7.6 11 5.3 12 3Z" />
      <path d="M12 20.5a3.2 3.2 0 0 1-3.2-3.2c0-1.5 1-2.6 3.2-4.3 2.2 1.7 3.2 2.8 3.2 4.3A3.2 3.2 0 0 1 12 20.5Z" opacity="0.6" />
    </svg>
  );
}

export function IconClock({ className = "w-5 h-5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 2" />
    </svg>
  );
}

export function IconWheat({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M12 21V9" />
      <path d="M12 12c-2.8 0-4.5-1.6-4.5-4.2C10.3 7.8 12 9.4 12 12Z" />
      <path d="M12 12c2.8 0 4.5-1.6 4.5-4.2C13.7 7.8 12 9.4 12 12Z" />
      <path d="M12 16.5c-2.8 0-4.5-1.6-4.5-4.2 2.8 0 4.5 1.6 4.5 4.2Z" />
      <path d="M12 16.5c2.8 0 4.5-1.6 4.5-4.2-2.8 0-4.5 1.6-4.5 4.2Z" />
      <path d="M12 9c-1.2-1.4-1.2-3.3 0-6 1.2 2.7 1.2 4.6 0 6Z" />
    </svg>
  );
}

export function IconDrop({ className = "w-6 h-6" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M12 3.5c3.5 4.2 6 7.3 6 10.5a6 6 0 0 1-12 0c0-3.2 2.5-6.3 6-10.5Z" />
      <path d="M9 14a3 3 0 0 0 2 2.7" opacity="0.6" />
    </svg>
  );
}

export function IconIG({ className = "w-5 h-5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <rect x="3.5" y="3.5" width="17" height="17" rx="4.5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function IconXSocial({ className = "w-5 h-5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M4.5 4.5 19.5 19.5M19.5 4.5 4.5 19.5" />
    </svg>
  );
}

export function IconYT({ className = "w-5 h-5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <rect x="2.5" y="5.5" width="19" height="13" rx="4" />
      <path d="M10.5 9.5v5l4.5-2.5-4.5-2.5Z" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function IconTT({ className = "w-5 h-5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base}>
      <path d="M14.5 3.5v10.8a3.9 3.9 0 1 1-3.3-3.85" />
      <path d="M14.5 5.2c.7 2.4 2.3 3.8 5 4" />
    </svg>
  );
}

/** Pizza ilustrada en SVG (hero + CTA). */
export function PizzaArt({ className = "w-full h-full" }: IconProps) {
  return (
    <svg viewBox="0 0 400 400" className={className} aria-hidden="true">
      <defs>
        <radialGradient id="pz-crust" cx="50%" cy="44%" r="60%">
          <stop offset="62%" stopColor="#F2CE96" />
          <stop offset="84%" stopColor="#E2A75C" />
          <stop offset="100%" stopColor="#C2752F" />
        </radialGradient>
        <radialGradient id="pz-sauce" cx="50%" cy="46%" r="58%">
          <stop offset="0%" stopColor="#E2552A" />
          <stop offset="100%" stopColor="#C43A17" />
        </radialGradient>
        <radialGradient id="pz-cheese" cx="46%" cy="42%" r="62%">
          <stop offset="0%" stopColor="#F8E3AC" />
          <stop offset="70%" stopColor="#F0D28A" />
          <stop offset="100%" stopColor="#E3B965" />
        </radialGradient>
        <radialGradient id="pz-pep" cx="35%" cy="30%" r="75%">
          <stop offset="0%" stopColor="#DB4A30" />
          <stop offset="100%" stopColor="#A3271A" />
        </radialGradient>
        <radialGradient id="pz-burn" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#8A4A15" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#8A4A15" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="200" cy="200" r="192" fill="url(#pz-crust)" />
      {/* burbujas de la bordura */}
      <g fill="url(#pz-burn)">
        <circle cx="200" cy="34" r="9" />
        <circle cx="304" cy="62" r="7" />
        <circle cx="366" cy="142" r="8" />
        <circle cx="368" cy="252" r="6" />
        <circle cx="306" cy="338" r="8" />
        <circle cx="200" cy="367" r="7" />
        <circle cx="94" cy="338" r="8" />
        <circle cx="32" cy="252" r="6" />
        <circle cx="34" cy="142" r="8" />
        <circle cx="96" cy="62" r="7" />
      </g>
      <circle cx="200" cy="200" r="158" fill="url(#pz-sauce)" opacity="0.95" />
      <circle cx="200" cy="200" r="152" fill="url(#pz-cheese)" />
      {/* queso fundido irregular */}
      <g fill="#FFF6DF" opacity="0.5">
        <ellipse cx="150" cy="150" rx="34" ry="20" transform="rotate(-18 150 150)" />
        <ellipse cx="252" cy="210" rx="30" ry="17" transform="rotate(14 252 210)" />
        <ellipse cx="180" cy="262" rx="26" ry="15" transform="rotate(-8 180 262)" />
      </g>
      <g fill="#D9A24C" opacity="0.45">
        <ellipse cx="232" cy="132" rx="18" ry="10" />
        <ellipse cx="128" cy="216" rx="16" ry="9" />
      </g>
      {/* pepperoni */}
      <g>
        {[
          [152, 138, 30],
          [248, 158, 28],
          [206, 236, 32],
          [136, 232, 26],
          [272, 232, 24],
        ].map(([x, y, r], i) => (
          <g key={i}>
            <circle cx={x} cy={y} r={r} fill="url(#pz-pep)" />
            <circle cx={x - r * 0.3} cy={y - r * 0.35} r={r * 0.18} fill="#F28A6B" opacity="0.7" />
            <circle cx={x + r * 0.35} cy={y + r * 0.2} r={r * 0.12} fill="#7C150A" opacity="0.6" />
          </g>
        ))}
      </g>
      {/* albahaca */}
      <g fill="#5E9447">
        <path d="M185 172c14-14 30-14 34 0-14 14-30 14-34 0Z" transform="rotate(24 202 172)" />
        <path d="M118 178c12-12 26-12 30 0-12 12-26 12-30 0Z" transform="rotate(-30 133 178)" />
        <path d="M240 278c12-12 26-12 30 0-12 12-26 12-30 0Z" transform="rotate(12 255 278)" />
        <path d="M168 296c11-11 23-11 27 0-11 11-23 11-27 0Z" transform="rotate(-18 181 296)" />
      </g>
      {/* motas de harina */}
      <g fill="#FBF3E2" opacity="0.6">
        <circle cx="170" cy="110" r="2.4" />
        <circle cx="262" cy="118" r="2" />
        <circle cx="300" cy="200" r="2.4" />
        <circle cx="102" cy="196" r="2" />
        <circle cx="222" cy="304" r="2.2" />
        <circle cx="148" cy="270" r="1.8" />
      </g>
    </svg>
  );
}
