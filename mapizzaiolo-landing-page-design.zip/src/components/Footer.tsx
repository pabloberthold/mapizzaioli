import { useState, type FormEvent } from "react";
import { IconArrow, IconCheck, IconIG, IconTT, IconXSocial, IconYT, LogoMark } from "./icons";

const COLS = [
  {
    title: "Producto",
    links: ["Calculadora", "Fórmulas de obrador", "Presets por estilo", "Precios", "Changelog"],
  },
  {
    title: "Recetas",
    links: ["Napolitana desde cero", "RML de 48 horas", "Romana de barra", "Guía de hidratación", "Pan de masa madre"],
  },
  {
    title: "Ma'pizzaiolo",
    links: ["Manifiesto", "Blog del obrador", "Prensa", "Comunidad", "Contacto"],
  },
];

export default function Footer() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (email.trim()) setSent(true);
  };

  return (
    <footer className="relative bg-[#080604] border-t border-cream/10">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 pt-16 pb-8">
        <div className="grid gap-12 lg:gap-8 lg:grid-cols-12">
          {/* Marca + newsletter */}
          <div className="lg:col-span-5">
            <a href="#inicio" className="flex items-center gap-2.5 w-fit" aria-label="Ma'pizzaiolo — inicio">
              <LogoMark className="w-9 h-9" />
              <span className="font-display text-xl font-semibold tracking-tight">
                Ma&rsquo;pizzaiolo
              </span>
            </a>
            <p className="mt-4 max-w-sm text-[14px] leading-relaxed text-cream-dim">
              Fórmulas interactivas para calcular la masa de tu pizza perfecta.
              Del porcentaje de panadero al gramo de tu báscula.
            </p>

            <p className="mt-7 font-calc text-[11px] uppercase tracking-[0.22em] text-cream-dim/80">
              La fórmula del domingo
            </p>
            {sent ? (
              <p className="mt-3 inline-flex items-center gap-2 text-[13.5px] font-semibold text-basil">
                <IconCheck className="w-4 h-4" /> ¡Listo! Revisa tu correo, la primera ya va en camino.
              </p>
            ) : (
              <form onSubmit={onSubmit} className="mt-3 flex max-w-sm gap-2">
                <label htmlFor="newsletter" className="sr-only">
                  Tu correo electrónico
                </label>
                <input
                  id="newsletter"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tu@correo.com"
                  className="flex-1 min-w-0 rounded-full bg-cream/5 border border-cream/15 px-5 py-3 text-[13.5px] text-cream placeholder:text-cream-dim/60 focus:border-gold/60 transition-colors"
                />
                <button
                  type="submit"
                  aria-label="Suscribirme"
                  className="w-11 h-11 shrink-0 rounded-full bg-gradient-to-br from-ember to-ember-deep text-ink-deep grid place-items-center hover:scale-110 active:scale-95 transition-transform cursor-pointer"
                >
                  <IconArrow className="w-5 h-5" />
                </button>
              </form>
            )}
            <p className="mt-2.5 text-[11.5px] text-cream-dim/70">
              Una fórmula nueva cada semana. Cero spam, promesa de pizzaiolo.
            </p>
          </div>

          {/* Columnas */}
          <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-8">
            {COLS.map((col) => (
              <nav key={col.title} aria-label={col.title}>
                <p className="font-calc text-[11px] uppercase tracking-[0.22em] text-cream-dim/80 mb-4">
                  {col.title}
                </p>
                <ul className="space-y-2.5">
                  {col.links.map((l) => (
                    <li key={l}>
                      <a
                        href="#calculadora"
                        className="text-[13.5px] text-cream-dim hover:text-gold transition-colors duration-300"
                      >
                        {l}
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>
        </div>

        {/* Barra inferior */}
        <div className="mt-14 pt-7 border-t border-cream/10 flex flex-col sm:flex-row items-center justify-between gap-5">
          <p className="text-[12.5px] text-cream-dim/80">
            © 2026 Ma&rsquo;pizzaiolo · Hecho con harina, fuego y código.
          </p>
          <div className="flex items-center gap-3">
            {[
              { label: "Instagram", icon: <IconIG className="w-4.5 h-4.5" /> },
              { label: "X", icon: <IconXSocial className="w-4.5 h-4.5" /> },
              { label: "YouTube", icon: <IconYT className="w-4.5 h-4.5" /> },
              { label: "TikTok", icon: <IconTT className="w-4.5 h-4.5" /> },
            ].map((s) => (
              <a
                key={s.label}
                href="#inicio"
                aria-label={s.label}
                className="w-10 h-10 rounded-full border border-cream/15 grid place-items-center text-cream-dim hover:text-gold hover:border-ember/60 hover:-translate-y-0.5 transition-all duration-300"
              >
                {s.icon}
              </a>
            ))}
          </div>
          <div className="flex items-center gap-5 text-[12px] text-cream-dim/70">
            <a href="#inicio" className="hover:text-gold transition-colors">Privacidad</a>
            <a href="#inicio" className="hover:text-gold transition-colors">Términos</a>
            <a href="#inicio" className="hover:text-gold transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
