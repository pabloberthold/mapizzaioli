import { useEffect, useRef, useState } from "react";
import { Reveal } from "../lib/motion";
import { IconArrow } from "./icons";

const BENEFITS = [
  {
    stat: "−72%",
    title: "Fracasos en la primera semana",
    desc: "Antes de mezclar sabes cuánta agua acepta tu harina y cómo se comportará la masa. Sin bollo gomoso, sin cemento de horno. La primera tanda ya sale bien.",
  },
  {
    stat: "0 g",
    title: "De masa a la basura",
    desc: "Calculas al gramo para tus bolas y tu horno. Lo que antes sobraba y tirabas, ahora es la pizza de mañana: la fórmula escala a cualquier cantidad exacta.",
  },
  {
    stat: "24–48 h",
    title: "Fermentación con calendario",
    desc: "La calculadora ajusta el tiempo en frío según tu hidratación y tu levadura. Tú decides cuándo hornea la familia; la masa hace la suya sin prisas.",
  },
  {
    stat: "1 → 40",
    title: "Bolas sin perder la proporción",
    desc: "Del ensayo de los jueves al horno lleno de un sábado: multiplica bolas sin tocar un porcentaje. El método aguanta cualquier volumen de masa.",
  },
];

const RAIL = [
  "Diagnóstico del estilo",
  "Fórmula al gramo",
  "Plan de fermentación",
  "Horno y repetición",
];

export default function Benefits() {
  const [active, setActive] = useState(0);
  const refs = useRef<(HTMLElement | null)[]>([]);

  useEffect(() => {
    const observers = refs.current
      .filter((el): el is HTMLElement => Boolean(el))
      .map((el, i) => {
        const io = new IntersectionObserver(
          (entries) => {
            if (entries[0].isIntersecting) setActive(i);
          },
          { rootMargin: "-45% 0px -45% 0px" }
        );
        io.observe(el);
        return io;
      });
    return () => observers.forEach((io) => io.disconnect());
  }, []);

  return (
    <section id="metodo" className="relative bg-parch text-ink-deep py-24 md:py-32 overflow-hidden">
      {/* textura sutil */}
      <div
        className="absolute inset-0 opacity-[0.35] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(rgba(25,18,7,0.08) 1px, transparent 1px)",
          backgroundSize: "26px 26px",
        }}
        aria-hidden="true"
      />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Columna sticky */}
          <div className="lg:col-span-5 lg:sticky lg:top-28">
            <Reveal>
              <p className="font-calc text-[11px] uppercase tracking-[0.3em] text-ember-deep mb-4">
                03 · El método
              </p>
              <h2 className="font-display text-4xl md:text-[2.9rem] font-semibold tracking-tight leading-[1.06]">
                Del «a ver cómo sale» al <em className="italic font-medium text-ember-deep">plan de obrador</em>.
              </h2>
              <p className="mt-5 text-[15.5px] leading-relaxed text-ink-deep/65 max-w-md">
                Lo que diferencia a la pizza de la esquina de la pizza de la esquina
                buena no es el horno: es que detrás hay números. Ma&rsquo;pizzaiolo te
                pone esos números en la mano, en cuatro pasos.
              </p>
            </Reveal>

            <Reveal delay={180} className="mt-10 relative">
              <div className="absolute left-[17px] top-3 bottom-3 w-px bg-ink-deep/15" aria-hidden="true">
                <div
                  className="w-full bg-gradient-to-b from-ember to-ember-deep transition-all duration-700 ease-out"
                  style={{ height: `${((active + 1) / RAIL.length) * 100}%` }}
                />
              </div>
              <ul className="space-y-5">
                {RAIL.map((label, i) => (
                  <li key={label} className="relative flex items-center gap-4">
                    <span
                      className={`relative z-10 w-9 h-9 rounded-full grid place-items-center font-calc text-[11px] font-semibold border transition-all duration-500 ${
                        active >= i
                          ? "bg-ember border-ember text-ink-deep scale-110 shadow-[0_6px_18px_-6px_rgba(232,80,26,0.7)]"
                          : "bg-parch border-ink-deep/20 text-ink-deep/50"
                      }`}
                      aria-hidden="true"
                    >
                      {i + 1}
                    </span>
                    <span
                      className={`text-[14.5px] transition-all duration-500 ${
                        active >= i ? "font-bold text-ink-deep" : "font-medium text-ink-deep/45"
                      }`}
                    >
                      {label}
                    </span>
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal delay={280} className="mt-10">
              <a href="#calculadora" className="btn-dark">
                Probar la calculadora <IconArrow className="w-5 h-5" />
              </a>
            </Reveal>
          </div>

          {/* Tarjetas que hacen scroll */}
          <div className="lg:col-span-7 space-y-6">
            {BENEFITS.map((b, i) => (
              <Reveal
                key={b.stat}
                delay={i * 60}
                className="group bg-[#FFFDF8] border border-ink-deep/10 rounded-2xl p-8 md:p-10 shadow-[0_2px_0_rgba(25,18,7,0.05)] hover:shadow-[0_26px_50px_-24px_rgba(25,18,7,0.3)] hover:-translate-y-1.5 transition-all duration-500"
              >
                <div
                  ref={(el) => {
                    refs.current[i] = el;
                  }}
                >
                  <p className="font-display text-5xl md:text-[3.4rem] font-semibold tracking-tight leading-none text-transparent bg-clip-text bg-gradient-to-br from-ember to-ember-deep">
                    {b.stat}
                  </p>
                  <h3 className="mt-4 font-display text-2xl font-semibold">{b.title}</h3>
                  <p className="mt-3 text-[15px] leading-relaxed text-ink-deep/65 max-w-xl">
                    {b.desc}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
