import type { ReactNode } from "react";
import { Reveal } from "../lib/motion";
import { IconCopy, IconDial, IconScale, IconSlice, IconSnow, IconStack } from "./icons";

interface Feature {
  icon: ReactNode;
  title: string;
  desc: string;
}

const FEATURES: Feature[] = [
  {
    icon: <IconDial className="w-6 h-6" />,
    title: "Fórmulas en % de panadero",
    desc: "Todo se construye sobre porcentajes: harina 100, agua, sal y levadura en su proporción. Cambia un número y la receta entera se reescribe contigo.",
  },
  {
    icon: <IconSlice className="w-6 h-6" />,
    title: "Presets por estilo",
    desc: "Napolitana, RML, romana, neoyorquina o siciliana. Cada estilo trae su hidratación, su sal y su fermentación probadas en obradores reales.",
  },
  {
    icon: <IconScale className="w-6 h-6" />,
    title: "Precisión al gramo",
    desc: "Adiós a las tazas: la masa es química y la química se pesa. Cada fórmula sale lista para tu báscula, con decimales cuando importan.",
  },
  {
    icon: <IconSnow className="w-6 h-6" />,
    title: "Fermentación guiada",
    desc: "Tiempo en frío o en ambiente calculado con tu hidratación y tu levadura. Saber cuándo pasa a la nevera y cuándo hornea, sin cronómetro mágico.",
  },
  {
    icon: <IconStack className="w-6 h-6" />,
    title: "Escala sin miedo",
    desc: "De 2 bolas de ensayo a 40 para el sábado de la familia: los porcentajes se mantienen intactos por mucha masa que multipliques.",
  },
  {
    icon: <IconCopy className="w-6 h-6" />,
    title: "Copia y repite",
    desc: "Exporta tu fórmula lista para la libreta, la nevera o el equipo del obrador. La pizza del domingo pasado se repite al gramo el próximo.",
  },
];

export default function Features() {
  return (
    <section id="formulas" className="relative py-24 md:py-32">
      <div className="orb w-[460px] h-[460px] bg-ember/10 top-10 -right-52" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14 md:mb-20">
          <Reveal>
            <p className="font-calc text-[11px] uppercase tracking-[0.3em] text-ember mb-4">
              01 · Las fórmulas
            </p>
            <h2 className="font-display text-4xl md:text-5xl font-semibold tracking-tight leading-[1.05] max-w-xl">
              Cada ingrediente,
              <br />
              en su <em className="italic text-gold font-medium">sitio exacto</em>.
            </h2>
          </Reveal>
          <Reveal delay={150} className="md:max-w-sm">
            <p className="text-cream-dim leading-relaxed">
              No es una calculadora con recetas guardadas: es un sistema que entiende
              la masa. Toca un preset, ajusta lo que quieras, y el resultado siempre
              respeta la física de la fermentación.
            </p>
          </Reveal>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f, i) => (
            <Reveal
              key={f.title}
              delay={(i % 3) * 110}
              className="group relative glass rounded-2xl p-7 hover:-translate-y-1.5 hover:border-ember/40 transition-all duration-500"
            >
              <span className="absolute top-6 right-7 font-calc text-[13px] text-cream/20 group-hover:text-ember/60 transition-colors duration-500">
                0{i + 1}
              </span>
              <div className="w-12 h-12 rounded-xl bg-ember/10 border border-ember/25 text-gold grid place-items-center mb-6 transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-6">
                {f.icon}
              </div>
              <h3 className="font-display text-xl font-semibold mb-2.5">{f.title}</h3>
              <p className="text-[14.5px] leading-relaxed text-cream-dim">{f.desc}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
