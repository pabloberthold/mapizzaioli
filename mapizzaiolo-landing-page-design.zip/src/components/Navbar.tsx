import { useEffect, useState } from "react";
import { LogoMark, IconMenu, IconX } from "./icons";

const LINKS = [
  { href: "#calculadora", label: "Calculadora" },
  { href: "#formulas", label: "Fórmulas" },
  { href: "#metodo", label: "Método" },
  { href: "#opiniones", label: "Opiniones" },
  { href: "#precios", label: "Precios" },
  { href: "#faq", label: "FAQ" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(max > 0 ? Math.min(1, window.scrollY / max) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-ink/80 backdrop-blur-xl border-b border-cream/10 shadow-[0_8px_30px_-12px_rgba(0,0,0,0.6)]"
          : "bg-transparent border-b border-transparent"
      }`}
    >
      {/* Barra de progreso de scroll */}
      <div
        className="absolute top-0 left-0 h-[2.5px] bg-gradient-to-r from-ember to-gold transition-[width] duration-150 ease-out"
        style={{ width: `${progress * 100}%` }}
        aria-hidden="true"
      />
      <nav
        className="mx-auto max-w-7xl px-5 sm:px-8 flex items-center justify-between h-[72px]"
        aria-label="Principal"
      >
        <a
          href="#inicio"
          className="flex items-center gap-2.5 group"
          aria-label="Ma'pizzaiolo — inicio"
        >
          <span className="transition-transform duration-500 group-hover:rotate-[30deg]">
            <LogoMark className="w-9 h-9" />
          </span>
          <span className="font-display text-xl font-semibold tracking-tight">
            Ma&rsquo;pizzaiolo
          </span>
        </a>

        <ul className="hidden lg:flex items-center gap-1">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="px-3.5 py-2 text-[13.5px] font-semibold text-cream-dim rounded-full hover:text-cream hover:bg-cream/5 transition-colors duration-300"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-3">
          <a
            href="#calculadora"
            className="btn-primary !py-2.5 !px-5 !text-[13.5px] hidden sm:inline-flex"
          >
            Calcular gratis
          </a>
          <button
            className="lg:hidden p-2.5 -mr-2 rounded-full text-cream hover:bg-cream/10 transition-colors"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="menu-movil"
            aria-label={open ? "Cerrar menú" : "Abrir menú"}
          >
            {open ? <IconX className="w-6 h-6" /> : <IconMenu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* Menú móvil */}
      <div
        id="menu-movil"
        className={`lg:hidden fixed inset-x-0 top-[72px] bottom-0 z-40 bg-ink/97 backdrop-blur-2xl transition-all duration-400 ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
      >
        <div className="px-8 pt-10 pb-16 flex flex-col">
          <ul className="flex flex-col gap-1">
            {LINKS.map((l, i) => (
              <li
                key={l.href}
                style={{ transitionDelay: open ? `${80 + i * 55}ms` : "0ms" }}
                className={`transition-all duration-500 ${
                  open ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
                }`}
              >
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block py-3.5 font-display text-3xl font-medium border-b border-cream/10 hover:text-gold transition-colors"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#calculadora"
            onClick={() => setOpen(false)}
            className="btn-primary mt-8 w-full"
          >
            Calcular mi masa gratis
          </a>
        </div>
      </div>
    </header>
  );
}
