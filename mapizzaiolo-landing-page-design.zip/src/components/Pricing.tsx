import { useState } from "react";
import { Reveal } from "../lib/motion";
import { IconCheck } from "./icons";

interface Tier {
  name: string;
  monthly: number;
  annual: number;
  desc: string;
  features: string[];
  cta: string;
  popular?: boolean;
}

const TIERS: Tier[] = [
  {
    name: "Aprendiz",
    monthly: 0,
    annual: 0,
    desc: "Para empezar a pesar en serio.",
    features: [
      "Calculadora completa",
      "5 estilos de pizza",
      "Fórmulas ilimitadas",
      "Copiar y exportar receta",
      "Comunidad de cocineros",
    ],
    cta: "Empezar gratis",
  },
  {
    name: "Artigiano",
    monthly: 7,
    annual: 4,
    desc: "Para quien ya no tira masa.",
    features: [
      "Todo lo de Aprendiz",
      "120+ fórmulas de obrador",
      "Planificador de fermentación",
      "Historial de tus recetas",
      "Exporta en PDF para imprimir",
      "Conversión a levadura seca",
      "Soporte por chat",
    ],
    cta: "Ser Artigiano",
    popular: true,
  },
  {
    name: "Maestro",
    monthly: 12,
    annual: 8,
    desc: "Para dominar la hidratación.",
    features: [
      "Todo lo de Artigiano",
      "Perfiles por tipo de harina",
      "Rampas de hidratación guiadas",
      "1 sesión en vivo al mes",
      "Acceso anticipado a funciones",
      "Insignia Maestro en la comunidad",
    ],
    cta: "Ser Maestro",
  },
];

export default function Pricing() {
  const [annual, setAnnual] = useState(true);

  return (
    <section id="precios" className="relative py-24 md:py-32 bg-ink-2/60 border-y border-cream/[0.07]">
      <div className="orb w-[480px] h-[480px] bg-ember/10 top-1/3 -right-56" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <Reveal>
            <p className="font-calc text-[11px] uppercase tracking-[0.3em] text-ember mb-4">
              05 · Precios
            </p>
            <h2 className="font-display text-4xl md:text-5xl font-semibold tracking-tight leading-[1.05]">
              Menos que <em className="italic text-gold font-medium">una pizza</em>. Más que una receta.
            </h2>
            <p className="mt-5 text-cream-dim leading-relaxed">
              Empieza gratis hoy. Sube de nivel cuando tu masa lo pida.
            </p>
          </Reveal>

          <Reveal delay={160} className="mt-9">
            <div
              className="inline-flex items-center gap-1 glass rounded-full p-1.5"
              role="group"
              aria-label="Período de facturación"
            >
              <button
                onClick={() => setAnnual(false)}
                aria-pressed={!annual}
                className={`rounded-full px-5 py-2 text-[13px] font-bold transition-all duration-300 cursor-pointer ${
                  !annual ? "bg-cream text-ink shadow" : "text-cream-dim hover:text-cream"
                }`}
              >
                Mensual
              </button>
              <button
                onClick={() => setAnnual(true)}
                aria-pressed={annual}
                className={`rounded-full px-5 py-2 text-[13px] font-bold transition-all duration-300 cursor-pointer ${
                  annual ? "bg-cream text-ink shadow" : "text-cream-dim hover:text-cream"
                }`}
              >
                Anual <span className={annual ? "text-ember-deep" : "text-gold"}>−30%</span>
              </button>
            </div>
          </Reveal>
        </div>

        <div className="grid md:grid-cols-3 gap-6 md:gap-5 lg:gap-7 items-stretch max-w-5xl mx-auto">
          {TIERS.map((t, i) => {
            const price = annual ? t.annual : t.monthly;
            const card = (
              <div
                className={`h-full flex flex-col rounded-[22px] p-7 md:p-8 transition-all duration-500 ${
                  t.popular
                    ? "bg-[#1C150E] hover:-translate-y-2"
                    : "glass hover:-translate-y-2 hover:border-cream/25"
                }`}
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-2xl font-semibold">{t.name}</h3>
                  {t.popular && (
                    <span className="font-calc text-[10px] tracking-[0.18em] bg-ember text-ink-deep font-semibold rounded-full px-3 py-1.5">
                      EL FAVORITO
                    </span>
                  )}
                </div>
                <p className="mt-1.5 text-[13.5px] text-cream-dim">{t.desc}</p>

                <div className="mt-7 flex items-end gap-2">
                  <span key={`${t.name}-${annual}`} className="fade-swap font-display text-5xl font-semibold tracking-tight">
                    ${price}
                  </span>
                  <span className="pb-1.5 text-[13px] text-cream-dim">/mes</span>
                </div>
                <p className="mt-1 font-calc text-[11px] text-cream-dim/80 h-4">
                  {t.monthly === 0
                    ? "gratis para siempre"
                    : annual
                      ? `facturado anualmente · $${t.annual * 12}/año`
                      : "sin compromiso, cancela cuando quieras"}
                </p>

                <ul className="mt-7 space-y-3 flex-1">
                  {t.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-[13.5px] text-cream/85">
                      <span
                        className={`mt-0.5 w-4.5 h-4.5 shrink-0 grid place-items-center rounded-full ${
                          t.popular ? "bg-ember/20 text-gold" : "bg-cream/10 text-cream-dim"
                        }`}
                        aria-hidden="true"
                      >
                        <IconCheck className="w-3 h-3" />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>

                <a
                  href={t.monthly === 0 ? "#calculadora" : "#cta"}
                  className={`mt-8 w-full ${t.popular ? "btn-primary" : "btn-ghost"}`}
                >
                  {t.cta}
                </a>
              </div>
            );
            return (
              <Reveal key={t.name} delay={i * 130} className="h-full">
                {t.popular ? (
                  <div className="h-full rounded-[23px] p-[1.5px] bg-gradient-to-b from-ember via-gold/70 to-ember/20 shadow-[0_30px_70px_-25px_rgba(255,107,44,0.45)]">
                    {card}
                  </div>
                ) : (
                  card
                )}
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={300} className="text-center mt-10">
          <p className="text-[12.5px] text-cream-dim">
            Precios en USD · Cambia de plan cuando quieras · 7 días de garantía en los planes de pago
          </p>
        </Reveal>
      </div>
    </section>
  );
}
