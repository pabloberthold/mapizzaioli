import { Reveal } from "../lib/motion";
import { IconQuote, IconStar } from "./icons";

const TESTIMONIALS = [
  {
    quote:
      "Pasé de recetas en vídeo a pesar todo al gramo. Mi napolitana por fin se extiende sin romperse, y el centro quedó húmedo como en la foto.",
    name: "Lucía M.",
    role: "Casa · Madrid, ES",
    ini: "LM",
    grad: "from-ember to-gold",
    rot: "md:-rotate-1",
  },
  {
    quote:
      "En el obrador usamos Ma'pizzaiolo para escalar lotes de 200 bolas. Los porcentajes nunca se van y el equipo nuevo entiende la fórmula en una mirada.",
    name: "Andrés T.",
    role: "Chef pizzero · La Cía. de Fornetti",
    ini: "AT",
    grad: "from-gold to-basil",
    rot: "md:rotate-1",
  },
  {
    quote:
      "La fermentación fría de 48 h con el preset RML me cambió la pizza: alvéolos enormes, miga abierta y un sabor a pan que no sabía que podía hacer en casa.",
    name: "Roberto S.",
    role: "Dueño · Fornetto, Buenos Aires",
    ini: "RS",
    grad: "from-ember-deep to-ember",
    rot: "md:-rotate-2",
  },
  {
    quote:
      "Explico el porcentaje de panadero a mis alumnas con la calculadora proyectada. Es la primera vez en diez años de docencia que nadie tira masa al tacho.",
    name: "Marta C.",
    role: "Docente · Escuela de Pan y Masa",
    ini: "MC",
    grad: "from-basil to-water",
    rot: "md:rotate-2",
  },
  {
    quote:
      "Le puse una hoja impresa en la nevera con la fórmula. Cada domingo: misma harina, mismos gramos, misma magia. Mis hijos ya piden «la de 7,4 gramos de sal».",
    name: "Diego R.",
    role: "Cocinero dominical · Lima, PE",
    ini: "DR",
    grad: "from-water to-ember",
    rot: "md:-rotate-1",
  },
  {
    quote:
      "Subí de 55% a 70% de hidratación en tres semanas siguiendo la rampa, sin perder el control de la masa. Mis pizzas ya no se parecen a las de la esquina.",
    name: "Carla V.",
    role: "Food creator · 214k seguidores",
    ini: "CV",
    grad: "from-gold to-ember-deep",
    rot: "md:rotate-1",
  },
];

export default function Testimonials() {
  return (
    <section id="opiniones" className="relative py-24 md:py-32">
      <div className="orb w-[440px] h-[440px] bg-gold/10 bottom-0 -left-48" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <Reveal>
            <p className="font-calc text-[11px] uppercase tracking-[0.3em] text-ember mb-4">
              04 · Opiniones
            </p>
            <h2 className="font-display text-4xl md:text-5xl font-semibold tracking-tight leading-[1.05]">
              Cocinas reales, <em className="italic text-gold font-medium">bordes perfectos</em>.
            </h2>
            <p className="mt-5 text-cream-dim leading-relaxed">
              De la barra a la casa, de 2 bolas a 200: así se lee la masa cuando
              deja de ser un misterio.
            </p>
          </Reveal>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-7">
          {TESTIMONIALS.map((t, i) => (
            <Reveal
              key={t.name}
              delay={(i % 3) * 120}
              className={`glass rounded-2xl p-7 ${t.rot} hover:rotate-0 hover:-translate-y-2 hover:border-gold/30 transition-all duration-500`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex gap-1 text-gold" aria-label="5 de 5 estrellas">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <IconStar key={s} className="w-3.5 h-3.5" />
                  ))}
                </div>
                <IconQuote className="w-6 h-6 text-ember/40" />
              </div>
              <blockquote className="text-[14.5px] leading-relaxed text-cream/90">
                «{t.quote}»
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3.5">
                <span
                  className={`w-11 h-11 rounded-full bg-gradient-to-br ${t.grad} grid place-items-center text-[12px] font-extrabold text-ink shrink-0`}
                  aria-hidden="true"
                >
                  {t.ini}
                </span>
                <span>
                  <span className="block text-[14px] font-bold text-cream">{t.name}</span>
                  <span className="block text-[12px] text-cream-dim mt-0.5">{t.role}</span>
                </span>
              </figcaption>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
