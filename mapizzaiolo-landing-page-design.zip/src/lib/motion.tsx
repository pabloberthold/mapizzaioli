import {
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";

/** Detecta prefers-reduced-motion en vivo. */
export function usePRM(): boolean {
  const [reduced, setReduced] = useState<boolean>(() =>
    typeof window !== "undefined" && "matchMedia" in window
      ? window.matchMedia("(prefers-reduced-motion: reduce)").matches
      : false
  );
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = () => setReduced(mq.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return reduced;
}

/** Observa un elemento una sola vez. */
export function useInViewOnce<T extends HTMLElement>(threshold = 0.15) {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || inView) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setInView(true);
          io.disconnect();
        }
      },
      { threshold, rootMargin: "0px 0px -40px 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold, inView]);
  return { ref, inView } as const;
}

/** Wrapper de scroll-reveal con stagger vía `delay` (ms). */
export function Reveal({
  children,
  delay = 0,
  className = "",
  as = "div",
  scale = false,
  style,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: string;
  scale?: boolean;
  style?: CSSProperties;
}) {
  const Tag = as as "div";
  const ref = useRef<HTMLElement | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          el.classList.add("in");
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -30px 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <Tag
      ref={ref as never}
      className={`rv ${scale ? "rv-scale" : ""} ${className}`}
      style={{ ...style, "--d": `${delay}ms` } as CSSProperties}
    >
      {children}
    </Tag>
  );
}

/** Número animado (ease-out). Con `fromZero` arranca desde 0 en vista. */
export function useCountUp(target: number, duration = 900, fromZero = false) {
  const reduced = usePRM();
  const [val, setVal] = useState<number>(fromZero ? 0 : target);
  const valRef = useRef<number>(fromZero ? 0 : target);
  valRef.current = val;
  useEffect(() => {
    if (reduced) {
      setVal(target);
      return;
    }
    const from = valRef.current;
    if (Math.abs(from - target) < 0.001) return;
    const t0 = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(from + (target - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration, reduced]);
  return val;
}

/** Contador que se anima al entrar en viewport. */
export function Counter({
  to,
  decimals = 0,
  prefix = "",
  suffix = "",
  duration = 1300,
  className = "",
}: {
  to: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  duration?: number;
  className?: string;
}) {
  const { ref, inView } = useInViewOnce<HTMLSpanElement>(0.4);
  const v = useCountUp(inView ? to : 0, duration, true);
  return (
    <span ref={ref} className={className}>
      {prefix}
      {v.toFixed(decimals).replace(".", ",")}
      {suffix}
    </span>
  );
}
