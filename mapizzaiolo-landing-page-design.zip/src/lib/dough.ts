export interface StylePreset {
  id: string;
  name: string;
  tag: string;
  hydration: number;
  salt: number;
  yeast: number;
  ferment: string;
  tip: string;
  dough: string;
}

export const PRESETS: StylePreset[] = [
  {
    id: "napoli",
    name: "Napolitana",
    tag: "NAPL · la referencia",
    hydration: 65,
    salt: 3,
    yeast: 0.3,
    ferment: "24 h en frío",
    tip: "Masa elástica y extensible con centro húmedo. Enciende el horno 45 min antes: piedra o plancha a máxima temperatura.",
    dough: "Extensible",
  },
  {
    id: "roma",
    name: "Romana",
    tag: "crispa, miga pareja",
    hydration: 60,
    salt: 3.5,
    yeast: 0.5,
    ferment: "24 h en frío",
    tip: "Menos agua, más estructura: bordes crujientes que aguantan ingredientes pesados. El estándar de la barra.",
    dough: "Estructurada",
  },
  {
    id: "rml",
    name: "RML",
    tag: "alta fermentación",
    hydration: 70,
    salt: 2.5,
    yeast: 0.1,
    ferment: "48 h en frío",
    tip: "Masa abierta con grandes alvéolos y sabor profundo. Trábajala en frío, con paciencia y mucho banco enharinado.",
    dough: "Alveolada",
  },
  {
    id: "ny",
    name: "Nueva York",
    tag: "14\", lista para plegar",
    hydration: 58,
    salt: 2.5,
    yeast: 0.8,
    ferment: "6–8 h en frío",
    tip: "Masa firme y flexible, hecha para doblarse. Más levadura compensa la hidratación baja sin perder sabor.",
    dough: "Flexible",
  },
  {
    id: "sicilia",
    name: "Siciliana",
    tag: "alta y esponjosa",
    hydration: 75,
    salt: 3,
    yeast: 0.3,
    ferment: "24 h en frío",
    tip: "Casi un pan: masa alta que crece en el molde. Espaciado generoso entre plegados y tolva de harina a mano.",
    dough: "Esponjosa",
  },
];

export interface DoughResult {
  flour: number;
  water: number;
  saltG: number;
  yeastG: number;
  total: number;
}

/** Cálculo por porcentaje de panadero: harina = 100%. */
export function calcDough(
  totalWeight: number,
  hydration: number,
  salt: number,
  yeast: number
): DoughResult {
  const sum = 1 + hydration / 100 + salt / 100 + yeast / 100;
  const flour = totalWeight / sum;
  const water = (flour * hydration) / 100;
  const saltG = (flour * salt) / 100;
  const yeastG = (flour * yeast) / 100;
  return { flour, water, saltG, yeastG, total: flour + water + saltG + yeastG };
}

/** Gramos con coma decimal cuando < 10 g. */
export function fmtG(n: number): string {
  if (n < 10) return n.toFixed(1).replace(".", ",");
  return Math.round(n).toString();
}

/** Fermentación dinámica según hidratación y levadura. */
export function fermentAdvice(
  hydration: number,
  yeast: number,
  base: StylePreset
): { range: string; note: string } {
  const slow = yeast <= 0.15;
  const fast = yeast >= 0.7;
  if (hydration >= 72) {
    return {
      range: slow ? "48–72 h en frío (4–6 °C)" : "36–48 h en frío",
      note: "Hidratación muy alta: la enzima hace su trabajo despacio. No prives a la masa de tiempo.",
    };
  }
  if (hydration >= 64) {
    return {
      range: fast ? "12–16 h en frío" : "24–48 h en frío",
      note: "Rango dulce del NAPL: equilibrio entre extensibilidad y sabor.",
    };
  }
  return {
    range: fast ? "8–12 h en frío o 3 h en ambiente" : "16–24 h en frío",
    note: `Hidratación firme: fermenta más rápido. Revisa el doblado de tamaño y prueba con el dedo (${base.name}).`,
  };
}
